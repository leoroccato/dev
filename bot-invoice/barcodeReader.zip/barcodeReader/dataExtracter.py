from pdf2image import convert_from_path
import pytesseract
import cv2
import re

pdf_path = r'C:\Users\leoro\Desktop\Projetos\DMStores\Automatização de Devoluções\barcodeReader\boletos\15342_davidgerais2001@gmail.com_BoletoBradesco_22012024_200318.pdf'

def DataExtracter(pdf_path):
    caminho = r"C:\Program Files\Tesseract-OCR"
    pytesseract.pytesseract.tesseract_cmd = caminho + r"\tesseract.exe"
    converted_pdf = convert_from_path(pdf_path, 500, poppler_path=r'C:\Program Files\poppler-23.11.0\Library\bin')[0]
    img = cv2.imread(converted_pdf)

    texto = pytesseract.image_to_string(img)
    print(texto)

    padrao_data_vencimento = re.compile(r'\d{2}/\d{2}/\d{4}\s+(\d{2}/\d{2}/\d{4})')
    correspondencias = padrao_data_vencimento.search(texto)

    if correspondencias:
        data_vencimento = correspondencias.group(1)
        print(f"Data de Vencimento: {data_vencimento}")
        return data_vencimento
    else:
        print("Data de Vencimento não encontrada")
